<?php
$host= "localhost";
$username= "N1000938";
$password= "10900";
$db= "m_itec30151_n1000938";

$conn= mysqli_connect($host, $username, $password, $db);

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
else
{

}

?>