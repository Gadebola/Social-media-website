<?php
session_start();
include "conn.php";

// Process message sending
if (isset($_POST['recipient'], $_POST['message']) && !empty($_POST['recipient']) && !empty($_POST['message'])) {
    $recipient = $_POST['recipient'];
    $message = $_POST['message'];
    $sender = $_SESSION['username'];

    // Insert the message into the database
    $sql = "INSERT INTO messages (sender, recipient, message) VALUES ('$sender', '$recipient', '$message')";
    if (mysqli_query($conn, $sql)) {
        // Echo the message sent confirmation
        echo "Message sent successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
} else {
    echo "Recipient and message cannot be empty";
}

// Process friend removal
if(isset($_POST['remove'])){
    $fname = $_POST['user'];
    $funi = $_POST['uni'];
    $fcourse = $_POST['course'];
    $uname = isset($_SESSION['username'])? $_SESSION['username'] : null;
    
    $sql_friends = mysqli_query($conn, "SELECT * FROM friend WHERE fname = '$fname' AND username ='$uname'");
    
    if(mysqli_num_rows($sql_friends) > 0){
        $del_friend= mysqli_query($conn, "DELETE FROM friend WHERE fname = '$fname' AND username ='$uname'");
    }
}
?>
