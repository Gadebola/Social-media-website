<?php
session_start();
include "conn.php";

if (!isset($_SESSION['username'])) {
    header('location:loginform.php');
}

if (isset($_POST['add'])) {
    if (isset($_SESSION['username'])) {
        $uname = isset($_SESSION['username']) ? $_SESSION['username'] : null;
        $friend = $_POST['user'];
        $uni = $_POST['uni'];
        $course = $_POST['course'];

        $sql_add = mysqli_query($conn, "SELECT * FROM friend WHERE fname = '$friend' AND username ='$uname'");

        if (mysqli_num_rows($sql_add) > 0) {
           
        } else {
            $add_product = mysqli_query($conn, "INSERT INTO friend (username, fname, funi, fcourse) VALUES ('$uname', '$friend', '$uni', '$course')");
        }
    }
}


$uname = isset($_SESSION['username']) ? $_SESSION['username'] : null;
$sql = mysqli_query($conn, "SELECT * FROM user WHERE username != '$uname'");

if (isset($_POST['filter'])) {
    $suni = $_POST['university'];


    if ($suni != "") {
        $sql = mysqli_query($conn, "SELECT * FROM user WHERE university = '$suni'");
    }
}

if (isset($_POST['filter_course'])) {
    $scourse = $_POST['course'];

 
    if ($scourse != "") {
        $sql = mysqli_query($conn, "SELECT * FROM user WHERE course = '$scourse'");
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>user page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link rel="stylesheet" href="Main.css">
</head>
<body>
<header>
<div class="containerr">
<a href="home.php"><img class="logo" src="images/Logo.png" alt="logo"></img></a>

<nav>
<ul>
<li><a href="home.php">Home</a></li>
<li><a href="friends.php">Friends</a></li>
<li><a href="user.php">profile</a></li>
</nav>
</ul>
</div>
  
</header>

<div class="form-box">
    <div class="button-box">
        <div class="btn-fr"></div>
        <button type="button" class="btn-active">Add friends</button>
        <button type="button" class="toggle-btn" onclick="location.href='newfr.php'">Friends</button>
    </div>
</div>

<form action="" method="post">
    <label for="universityFilter">Filter by University:</label>
    <select name="university" id="universityFilter">
        <option value="">All Universities</option>
		<option value ="University of Warwick">University of Warwick</option>
		<option value ="University of Birmingham"> University of Birmingham</option>
		<option value ="Aston University Birmingham">Aston University Birmingham</option>
		<option value ="Coventry University"> Coventry University</option>
		<option value ="University of Worcester"> University of Worcester</option>
		<option value ="Birmingham City University">Birmingham City University</option>
		<option value ="Staffordshire University">Staffordshire University</option>
		<option value ="University of Wolverhampton">University of Wolverhampton</option>
		<option value ="Nottingham Trent University">Nottingham Trent University</option>
		<option value ="University of Nottingham">University of Nottingham</option>
		<option value ="University of leicester">University of leicester</option>
		<option value ="University of Nottingham">University of Nottingham</option>
		<option value ="University of Cambridge">University of Cambridge</option>
		<option value ="University of Oxford">University of Oxford</option>
		<option value ="University of Bristol">University of Bristol</option>
		<option value ="University of Warwick">University of Warwick</option>
		<option value ="University of Manchester">University of Manchester</option>
		<option value ="University College London">University College London</option>
		<option value ="University of Lincoln">University of Lincoln</option>
        <!-- Add more options based on your actual universities -->
    </select>
    <input type="submit" class="btn-filter" value="Apply Filter" name="filter">
</form>

<form action="" method="post">
    <label for="courseFilter">Filter by Course:</label>
    <select name="course" id="courseFilter">
	<option value="">All courses</option>
		<option value ="Accounting">Accounting</option>
		<option value ="Arts and Humanities">Arts and Humanities</option>
		<option value ="Chemistry">Chemistry</option>
		<option value ="Computing and IT"> Computing and IT</option>
		<option value ="Creative Arts"> Creative Arts</option>
		<option value ="Criminology">Criminology</option>
		<option value ="Design">Design</option>
		<option value ="Economics">Economics</option>
		<option value ="Engineering">Engineering</option>
		<option value ="Film and Media">Film and Media</option>
		<option value ="Forensic Science">Forensic Science</option>
		<option value ="Law">Law</option>
		<option value ="Mathematics">Mathematics</option>
		<option value ="Music">Music</option>
		<option value ="Nursing">Nursing</option>
		<option value ="Pharmacology and Pharmacy">Pharmacology and Pharmacy</option>
		<option value ="Politics">Politics</option>
		<option value ="Psychology">Psychology</option>
		<option value ="Sports Science">Sports Science</option>
        <!-- Add more options as needed -->
    </select>
    <input type="submit" class="btn-filter" value="Apply Filter" name="filter_course">
</form>


<div class="container">
    <?php
    if (mysqli_num_rows($sql) > 0) {
        while ($fetch_users = mysqli_fetch_assoc($sql)) {
            ?>
            <div class="profile_box">
                <form action="" method="post">
                    <img src="images/profile.png" alt="user" width="50px">
                    <h4><?php echo $fetch_users['username']; ?></h4>
                    <h4>University: <?php echo $fetch_users['university']; ?></h4>
                    <h4>Course: <?php echo $fetch_users['course']; ?></h4>
                    <input type="hidden" name="user" value="<?php echo $fetch_users['username']; ?>">
                    <input type="hidden" name="uni" value="<?php echo $fetch_users['university']; ?>">
                    <input type="hidden" name="course" value="<?php echo $fetch_users['course']; ?>">
                    <input type="submit" class="btn-add" value="Add" name="add"></input>
                </form>
            </div>
        <?php
        }
    }
    ?>
</div>

</body>
</html>
