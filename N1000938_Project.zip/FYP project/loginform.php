<!DOCTYPE html>
<html>
<head>
<link href="login.css" type="text/css" rel="stylesheet"> 
</head>
<body>
	<div class="container">
		<h1 class="title">Login</h1>
		<form class="loginform" method="post" name="loginform" >
		<div class="user">Username</div>
		<input type="user" name="username">
			<div class="des des2">Password</div>
			<input type="password" name="password">
		
			
			<button type="submit" name="btnlogin">Login</button>
			<P>Create an account?<a href="Register.php">Register now</a></p>
			<P>Login to admin account?<a href="admin.php">admin login</a></p>
			
		</form>
	</div>

	
	
</body>








</body>
</html>


<?php
session_start();
include "conn.php";

if(isset($_POST['btnlogin'])){
	
$username= $_POST["username"];
$pass = $_POST["password"];


$select = "SELECT * FROM user WHERE username='$username' && BINARY password = '$pass' ";
$result = mysqli_query($conn, $select);
$row = mysqli_fetch_assoc($result);

if(mysqli_num_rows($result)== 1){
	$_SESSION["username"] = $username;
	$_SESSION["ID"] = $row["ID"];
	header("location: user.php");
}
else{
	echo '<div class="error-message">Invalid password or username</div>';


	
}
}


?>