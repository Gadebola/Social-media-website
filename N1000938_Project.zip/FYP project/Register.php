<!DOCTYPE html>
<html>
<head>
<link href="login.css" type="text/css" rel="stylesheet"> 
</head>
<body>
	<div class="container">
		<h1 class="title">Register</h1>
		<form class="loginform" action="" method="post" name="loginform" onsubmit="return validated()" >
		<div id="user">Username</div>
		<input type="user" name="username">
			<div class="des">Email or Phone</div>
			<input type="user" name="email">
			<div class="des des2">Password</div>
			<input type="password" name="password">
			<div class="des des2"> Confirm Password</div>
			<input type="password" name="cpassword">
			
			University
		<div class ="sel">
		<label for "uni"></label>
		<select name="uni" class ="sel-box" >
		<option value ="University">University</option>
		<option value ="University of Warwick">University of Warwick</option>
		<option value ="University of Birmingham"> University of Birmingham</option>
		<option value ="Aston University, Birmingham">Aston University, Birmingham</option>
		<option value ="Coventry University"> Coventry University</option>
		<option value ="University of Worcester"> University of Worcester</option>
		<option value ="Birmingham City University">Birmingham City University</option>
		<option value ="Staffordshire University">Staffordshire University</option>
		<option value ="University of Wolverhampton">University of Wolverhampton</option>
		<option value ="Nottingham Trent University">Nottingham Trent University</option>
		<option value ="University of leicester">University of leicester</option>
		<option value ="University of Nottingham">University of Nottingham</option>
		<option value ="University of Cambridge">University of Cambridge</option>
		<option value ="University of Oxford">University of Oxford</option>
		<option value ="University of Bristol">University of Bristol</option>
		<option value ="University of Warwick">University of Warwick</option>
		<option value ="University of Manchester">University of Manchester</option>
		<option value ="University College London">University College London</option>
		<option value ="University of Lincoln">University of Lincoln</option>
		</select>
		
		</div>
		
		Course
		<div class ="course">
		<label for "course"></label>
		<select name="course" class ="sel-box" >
		<option value ="University">Course</option>
		<option value ="Accounting">Accounting</option>
		<option value ="Arts and Humanities">Arts and Humanities</option>
		<option value ="Chemistry">Chemistry</option>
		<option value ="Computing and IT"> Computing and IT</option>
		<option value ="Creative Arts"> Creative Arts</option>
		<option value ="Criminology">Criminology</option>
		<option value ="Design">Design</option>
		<option value ="Economics">Economics</option>
		<option value ="Engineering">Engineering</option>
		<option value ="Film and Media">Film and Media</option>
		<option value ="Forensic Science">Forensic Science</option>
		<option value ="Law">Law</option>
		<option value ="Mathematics">Mathematics</option>
		<option value ="Music">Music</option>
		<option value ="Nursing">Nursing</option>
		<option value ="Pharmacology and Pharmacy">Pharmacology and Pharmacy</option>
		<option value ="Politics">Politics</option>
		<option value ="Psychology">Psychology</option>
		<option value ="Sports Science">Sports Science</option>
				
		</select>
		
		</div>
		
		start year
		<div class ="start">
		<label for "start"></label>
		<select name="start" class ="sel-box ">
		<option value ="University">Start Year</option>
		<option value ="2024">2024</option>
		<option value ="2023">2023</option>
		<option value ="2022">2022</option>
		<option value ="2021">2021</option>
		<option value ="2020">2020</option>
		<option value ="2019">2019</option>
		<option value ="2018">2018</option>
			
		</select>
			<button type="submit" name="btnlogin">next</button>
			<P>Already have an account?<a href="loginform.php">Login now</a></p>
			
		</form>
	</div>
	
<?php
session_start();
include "conn.php";
if(isset($_POST['btnlogin'])){
	if(isset($_POST["username"])){
	$username= $_POST["username"];
	}
	else{
		echo "<script>alert('usernmae not set')</script>";
	}
	
	if(isset($_POST["email"])){
	$email = $_POST["email"];
	}
	if(isset($_POST["password"])){
	$pass = $_POST["password"];
	}
	if(isset($_POST["cpassword"])){
	$cpass = $_POST["cpassword"];
	}
	if(isset($_POST["uni"])){
	$uniname = $_POST["uni"];
	}
	if(isset($_POST["course"])){
	$unicourse = $_POST["course"];
	}
	if(isset($_POST["start"])){
	$unistart= $_POST["start"];
	}


$select = "SELECT * FROM user WHERE username='$username' && password = '$pass' ";
$select_user = "SELECT * FROM user WHERE username='$username'";
$result = mysqli_query($conn, $select_user);
if(mysqli_num_rows($result) > 0){
	echo "<script>alert('user already exist')</script>";
	
}else{
	if($pass != $cpass){
		echo"<script>alert('password not matched')</script>";;
	}else{
			$sql="INSERT INTO user (username, email, password, cpassword, university, course, year) VALUES('".$username."', '".$email."', '".$pass."', '".$cpass."', '".$uniname."', '".$unicourse."', '".$unistart."')";
			mysqli_query($conn, $sql);
			header("Location:loginform.php");
	}
}


}



?>

	
	
	










</body>
</html>