<!DOCTYPE html>
<html lang="en">
<head>
<title>user page</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" href="Main.css">
<link rel="stylesheet" href=
"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
</head>
<header>
<div class="containerr">

<a href="home.php"><img class="logo" src="images/Logo.png" alt="logo"></img></a>

<na`v>
<ul>
<li><a href="home.php">Home</a></li>
<li><a href="friends.php">Friends</a></li>
<li><a href="user.php">profile</a></li>
</nav>
</ul>
</div>
</header>

<div class= "box1">
<div class="desc">
<h1> Find friends within your university now<br> and upgrade your univeristy exprience</h1>
<p>This website allows you to find friends based on search filters and preferences you select. You can find friendss based on thier university course or intrest so find friends catered to you now</p>
    <div class="button-container">
      <a href="friends.php" class="round-button">Go to Friends Page</a>
    </div>
</div>
<a href=""><img class="promo" src="images/friends.png" alt="logo"></img></a>


</div>

<div class= "box2">
<div class="desc2">
<h1> Create an account now to make close friends<br>Creeating an account with your details to make<br> you eaiser to find</h1>
<p>Creating an account gives you the chance to make more friends by registering with <br>the correct details others can see your acount based on the details you registered with.<br> Make an account now!!!!</p>
          <div class="button-container2">
	  <a href="loginform.php" class="round-button2">Make an account</a>
    </div>
</div>
<a href="home.php"><img class="promo2" src="images/login.png" alt="login"></img></a>


</div>

<footer>
    <div class="footer-wrapper">
        <h2>Gabriel Adebola N1000938</h2>
        <p>Be sure to look at my other social media:</p>
        <ul class="social-media">
            <li><a href="https://www.facebook.com/gabriel.adebola.10"><i class="fa fa-facebook"></i></a></li>
            <li><a href="https://twitter.com/mvpp_ga"><i class="fa fa-twitter"></i></a></li>
            <li><a href="https://www.linkedin.com/in/gabriel-adebola-01014025a/"><i class="fa fa-linkedin"></i></a></li>
            <li><a href="https://www.youtube.com/@gabzldn"><i class="fa fa-youtube"></i></a></li>
        </ul>
        <div class="footer-info">
            <p>Copyright © 2024 Gabriel/NTU. All rights reserved.</p>
        </div>
    </div>
</footer>



