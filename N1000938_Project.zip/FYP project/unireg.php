<!DOCTYPE html>
<html>
<head>
<link href="login.css" type="text/css" rel="stylesheet"> 
</head>
<body>
	<div class="container">
		<h1 class="title">Register</h1>
		<form class="loginform" action="" method="post" name="loginform" onsubmit="return validated()" >
		University
		<div class ="sel">
		<label for "uni"></label>
		<select name="uni" class ="sel-box" >
		<option value ="University">University</option>
		<option value ="University">University of Warwick</option>
		<option value ="University"> University of Birmingham</option>
		<option value ="University">Aston University Birmingham</option>
		<option value ="University"> Coventry University</option>
		<option value ="University"> University of Worcester</option>
		<option value ="University">Birmingham City University</option>
		<option value ="University">Staffordshire University</option>
		<option value ="University">University of Wolverhampton</option>
		<option value ="University">Nottingham Trent University</option>
		<option value ="University">University of Nottingham</option>
		<option value ="University">University of leicester</option>
		</select>
		
		</div>
		
		Course
		<div class ="course">
		<label for "course"></label>
		<select name="course" class ="sel-box" >
		<option value ="University">Course</option>
		<option value ="University">Accounting</option>
		<option value ="University">Arts and Humanities</option>
		<option value ="University">Chemistry</option>
		<option value ="University"> Computing and IT</option>
		<option value ="University"> Creative Arts</option>
		<option value ="University">Criminology</option>
		<option value ="University">Design</option>
		<option value ="University">Economics</option>
		<option value ="University">Engineering</option>
		<option value ="University">Film and Media</option>
		</select>
		
		</div>
		
		start year
		<div class ="start">
		<label for "start"></label>
		<select name="start" class ="sel-box ">
		<option value ="University">Start Year</option>
		<option value ="University">2024</option>
		<option value ="University">2023</option>
		<option value ="University">2022</option>
		<option value ="University">2021</option>
		<option value ="University">2020</option>
		<option value ="University">2019</option>
		<option value ="University">2018</option>
		
	
		</select>
		
		</div>
	
			
			
			<button type="submit" name="next">next</button>
			<P>Already have an account?<a href="login.php">Login now</a></p>
			
		</form>
	</div>

<?php
session_start();
include "conn.php";
if(isset($_SESSION['username'])){
	echo('logged in');
}

if(isset($_POST['next'])){
	if(isset($_SESSION['username'])){
	$uniname = $_POST['uni'];
	$unicourse = $_POST['course'];
	$unistart= $_POST['start'];
	$uname = isset($_SESSION['username'])? $_SESSION['username'] : null;
	
	$sql_log =  mysqli_query($conn, "select * from unidata where username ='$uname'");
	
	if(mysqli_num_rows($sql_log) > 0){
		echo "<script>alert('user already exist')</script>";
	}
	else{
		
		$sql="INSERT INTO unidata (username, University, Course, Start year) VALUES ('$uname', '$uniname', '$unicourse', '$unistart')";
		$sql_run= mysqli_query(conn,$sql);
			header("Location:loginform.php");
			
}
}
}





?>

	
	
	










</body>
</html>