function toggleChatBox(fname) {
    var chatBoxContainer = document.getElementById('chatBoxContainer_' + fname);
    if (!chatBoxContainer) return;

    if (chatBoxContainer.style.display === 'none') {
        chatBoxContainer.style.display = 'block';
    } else {
        chatBoxContainer.style.display = 'none';
    }
}

function closeChatBox(fname) {
    var chatBoxContainer = document.getElementById('chatBoxContainer_' + fname);
    if (chatBoxContainer) {
        chatBoxContainer.style.display = 'none';
    }
}

function sendMessage(fname) {
    var messageInput = document.getElementById('messageInput_' + fname).value;
    var messageStatus = document.getElementById('messageStatus' + fname);

    var xhr = new XMLHttpRequest();
    xhr.open("POST", "process.php", true); // Sending POST request to the process.php file
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // Handle the response from the server
            var messageStatus = xhr.responseText;
            // Update the message status element on the page
            document.getElementById('messageStatus' + fname).innerText = messageStatus;
            // Clear the message input after sending
            document.getElementById('messageInput_' + fname).value = '';
        }
    };
    xhr.send("recipient=" + fname + "&message=" + encodeURIComponent(messageInput));
}
