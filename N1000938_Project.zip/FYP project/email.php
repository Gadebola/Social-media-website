<!DOCTYPE html>
<html>
<head>
<link href="login.css" type="text/css" rel="stylesheet"> 
</head>
<body>
	<div class="container">
		<h1 class="title">Change Email</h1>
		<form class="loginform" action="" method="post" name="loginform" onsubmit="return validated()" >
			<div class="des">Enter usernmae</div>
			<input type="text" name="username">
		<div id="user">New email or phone number</div>
		<input type="text" name="new_email">
			<div class="des des2">Password</div>
			<input type="password" name="password">
			
			
			<button type="submit" name="btnlogin">Login</button>
			
		</form>
	</div>

	
	
	
</body>

</body>
<?php
session_start();
include "conn.php";
if(isset($_POST['btnlogin'])){
	$pass = $_POST["password"];
	$newemail = $_POST["new_email"];
	$uname= $_POST['username'];

$select = "SELECT * FROM User WHERE username='$uname' && BINARY password = '$pass' ";
$result = mysqli_query($conn, $select);
if(mysqli_num_rows($result) > 0){
	$sql= mysqli_query($conn, "UPDATE User SET email='$newemail' WHERE username='$uname'");
	header("Location:user.php");
	
}
else{
			echo"<script>alert('username or password is incorrect')</script>";
			
	}
}





?>







</html>