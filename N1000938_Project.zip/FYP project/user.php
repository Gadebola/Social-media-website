<?php
session_start();
include "conn.php";

if(!isset($_SESSION['username'])){
	header('location:loginform.php');
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>user page</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" href="Main.css">
</head>
<header>
<div class="containerr">

<a href="home.php"><img class="logo" src="images/Logo.png" alt="logo"></img></a>

<nav>
<ul>
<li><a href="home.php">Home</a></li>
<li><a href="friends.php">Friends</a></li>
<li><a href="user.php">profile</a></li>
</nav>
</ul>
</div>
</header>
<body>
<div class="container">


   <div class="details">
      <h3>Hello</h3>
      <h1>welcome <span><?php echo $_SESSION['username']?></span></h1>
      <p>this is your profile page</p>
	  <button type="button" class="btn-view" onclick= "location.href='profile.php'">View profile</a></button>
	  <button type="button" class="btn" onclick= "location.href='logout.php'">logout</a></button>
   </div>

</div>
</body>
</html>
