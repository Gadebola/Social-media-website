<!DOCTYPE html>
<html lang="en">
<head>
<title>user page</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" href="Main.css">
</head>
<header>
<div class="containerr">

<a href="product.php"><img class="logo" src="images/Logo.png" alt="logo"></img></a>

<nav>
<ul>
<li><a href="home.php">Home</a></li>
<li><a href="friends.php">Friends</a></li>
<li><a href="user.php">profile</a></li>
</nav>
</ul>
</div>
</header>

<body>

<?php
session_start();
include "conn.php";
      $uname = $_SESSION["username"];
      $sql = mysqli_query($conn, "SELECT * FROM user Where username = '$uname'");
      if(mysqli_num_rows($sql) > 0){
         while($fetch_product = mysqli_fetch_assoc($sql)){
		 
	  




?>

<div class="user-wrapper">
    <div class="user-profile-box">
        <img src="images/profile.png" alt="user" width="100">
        <h4>Username</h4>
        <p><?php echo $fetch_product['username']; ?></p>
        <a href="newuser.php" class="change-btn">change username</a>
    </div>
    <div class="user-profile-details">
        <div class="user-info">
            <div class="user-info-data">
                <div class="user-data">
                    <h4>Email or phone number</h4>
                    <p><?php echo $fetch_product['email']; ?></p>
                    <a href="email.php" class="email-btn">change email/number</a>
                </div>
                <div class="user-data">
                    <h4>Password</h4>
                    <p><?php echo $fetch_product['password']; ?></p>
                    <a href="password.php" class="password-btn">change password</a>
                </div>
            </div>
        </div>
    </div>
</div>

	<?php
	 };
      };
	 ?>
	 
	
	
	
</div>
</body>
<html>