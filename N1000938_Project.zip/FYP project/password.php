<!DOCTYPE html>
<html>
<head>
<link href="login.css" type="text/css" rel="stylesheet"> 
</head>
<body>
	<div class="container">
		<h1 class="title">Change Password</h1>
		<form class="loginform" action="" method="post" name="loginform" onsubmit="return validated()" >
			<div class="des">Enter usernmae</div>
			<input type="text" name="username">
		<div id="user">Old password</div>
		<input type="text" name="old_pass">
			<div class="des des2"> New Password</div>
			<input type="password" name="newpass">
			<div class="des des2"> Confirm Password</div>
			<input type="password" name="cpassword">
			
			
			<button type="submit" name="btnlogin">Login</button>
			
		</form>
	</div>

	
	
	
</body>

</body>
<?php
session_start();
include "conn.php";
if(isset($_POST['btnlogin'])){
	$pass = $_POST["old_pass"];
	$newpass = $_POST["newpass"];
	$cnewpass = $_POST["cpassword"];
	$uname= $_POST['username'];

$select = "SELECT * FROM User WHERE username='$uname' && BINARY password = '$pass' ";
$result = mysqli_query($conn, $select);
if(mysqli_num_rows($result) > 0 && $newpass == $cnewpass){
	$sql= mysqli_query($conn, "UPDATE User SET password='$newpass', cpassword='$cnewpass' WHERE username='$uname'");
	header("Location:user.php");
	
}
else{
	echo"<script>alert('username or password is incorrect')</script>";
			
	}
}







?>







</html>