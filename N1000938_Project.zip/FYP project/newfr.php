<?php
session_start();
include "conn.php";

// Process message sending
if (isset($_POST['recipient'], $_POST['message']) && !empty($_POST['recipient']) && !empty($_POST['message'])) {
    $recipient = $_POST['recipient'];
    $message = $_POST['message'];
    $sender = $_SESSION['username'];

    // Insert the message into the database
    $sql = "INSERT INTO messages (sender, recipient, message) VALUES ('$sender', '$recipient', '$message')";
    if (mysqli_query($conn, $sql)) {
        // Echo the message sent confirmation
        echo "Message sent successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
} else {
   
}

// Process friend removal
if(isset($_POST['remove'])){
    $fname = $_POST['recipient'];
    $funi = $_POST['uni'];
    $fcourse = $_POST['course'];
    $uname = isset($_SESSION['username'])? $_SESSION['username'] : null;
    
    $sql_friends = mysqli_query($conn, "SELECT * FROM friend WHERE fname = '$fname' AND username ='$uname'");
    
    if(mysqli_num_rows($sql_friends) > 0){
        $del_friend= mysqli_query($conn, "DELETE FROM friend WHERE fname = '$fname' AND username ='$uname'");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>User Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link rel="stylesheet" href="Main.css">
    <script src="website.js"></script>
</head>
<body>
    <header>
        <div class="containerr">
            <a href="home.php"><img class="logo" src="images/Logo.png" alt="logo"></img></a>
            <nav>
                <ul>
                    <li><a href="home.php">Home</a></li>
                    <li><a href="friends.php">Friends</a></li>
                    <li><a href="user.php">Profile</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="form-box">
        <div class="button-box">
            <div class="btn-fr"></div>
            <button type="button" class="toggle-btn" onclick= "location.href='friends.php'">Add friends</button>
            <button type="button" class="btn-active">Friends</button>
        </div>
    </div>

    <?php
    $uname = isset($_SESSION['username']) ? $_SESSION['username'] : null;
    $sql = mysqli_query($conn, "SELECT * FROM friend WHERE username = '$uname'");

    if (mysqli_num_rows($sql) > 0) {
        while ($row = mysqli_fetch_assoc($sql)) {
            $fname = $row["fname"];
            $funi = $row["funi"];
            $fcourse = $row["fcourse"];
    ?>
            <div class="cont">
                <section class="item">
                    <div class="item-container">
                        <div class="box">
                            <img src="images/profile.png" alt="user" width="100%">
                            <h3><?php echo $fname; ?></h3>
                            <h4>University: <?php echo $funi; ?></h4>
                            <h4>Course: <?php echo $fcourse; ?></h4>
                            <form id="messageForm" method="post" action="">
                                <input type="hidden" name="recipient" value="<?php echo $fname; ?>">
                                <input type="hidden" name="uni" value="<?php echo $funi; ?>">
                                <input type="hidden" name="course" value="<?php echo $fcourse; ?>">
                                <input type="submit" class="btn-add" value="Remove" name="remove">
                            </form>
                            <button type="button" class="btn-message" onclick="toggleChatBox('<?php echo $fname; ?>')">Message</button>
                        </div>
                    </div>
                </section>
            </div>

            <div class="chat-box-container" id="chatBoxContainer_<?php echo $fname; ?>" style="display: none;">
                <div class="chat-box-header">
                    <h3><?php echo $fname; ?></h3>
                    <button type="button" class="close-btn" onclick="closeChatBox('<?php echo $fname; ?>')">Close</button>
                </div>
                <div class="chat-box-messages" id="chatBox_<?php echo $fname; ?>">
                    <?php
                    // Fetch and display sent messages
                    $sql_messages1 = "SELECT * FROM messages WHERE (sender = '$uname' AND recipient = '$fname') OR (sender = '$fname' AND recipient = '$uname')";
                    $result_messages = mysqli_query($conn, $sql_messages1);
                    if (mysqli_num_rows($result_messages) > 0) {
                        while ($row = mysqli_fetch_assoc($result_messages)) {
                            $message_sender = $row['sender'];
                            $message = $row['message'];
                    ?>
                            <div class="message">
                                <p class="cmessages"><strong><?php echo $message_sender; ?>:</strong> <?php echo $message; ?></p>
                            </div>
                    <?php
                        }
                    } else {
                        echo "<p>No messages yet.</p>";
                    }
                    ?>
                </div>
                <div class="chat-box-input">
                    <input type="text" id="messageInput_<?php echo $fname; ?>" placeholder="Type your message...">
                    <button type="button" onclick="sendMessage('<?php echo $fname; ?>')">Send</button>
                    <div id="messageStatus<?php echo $fname; ?>"></div> 
                </div>
            </div>
    <?php
        }
    }
    ?>
</body>
</html>
