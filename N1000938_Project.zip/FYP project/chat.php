<!DOCTYPE html>
<html lang="en">
<head>
<title>user page</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" href="Main.css">
</head>
<header>
<div class="containerr">

<a href="product.php"><img class="logo" src="images/Logo.png" alt="logo"></img></a>

<nav>
<ul>
<li><a href="home.php">Home</a></li>
<li><a href="chat.php">Chats</a></li>
<li><a href="friends.php">Friends</a></li>
<li><a href="user.php">profile</a></li>
</nav>
</ul>
</div>