<!DOCTYPE html>
<html>
<head>
<link href="login.css" type="text/css" rel="stylesheet"> 
</head>
<body>
	<div class="container">
		<h1 class="title">Change Username</h1>
		<form class="loginform" action="" method="post" name="loginform" onsubmit="return validated()" >
			<div class="des">Email or Phone you used to register</div>
			<input type="text" name="email">
		<div id="user">New username</div>
		<input type="text" name="new_username">
			<div class="des des2">Password</div>
			<input type="password" name="password">
			
			
			<button type="submit" name="btnlogin">Login</button>
			
		</form>
	</div>

	
	
	
</body>
<?php
session_start();
include "conn.php";
if(isset($_POST['btnlogin'])){
	$pass = $_POST["password"];
	$newuname = $_POST["new_username"];
	$email= $_POST['email'];
	$uname= isset($_SESSION['username'])? $_SESSION['username'] : null;

$select = "SELECT * FROM User WHERE email='$email' && BINARY password = '$pass' ";
$result = mysqli_query($conn, $select);
if(mysqli_num_rows($result) > 0){
	$sql= mysqli_query($conn, "UPDATE User SET username='$newuname' WHERE email='$email'");
	$sql= mysqli_query($conn, "UPDATE friend SET username='$newuname' WHERE username='$uname'");
	$sql= mysqli_query($conn, "UPDATE messages SET sender='$newuname' WHERE sender='$uname'");
	header("Location:loginform.php");
	
}
else{
			echo"<script>alert('email or password is incorrect')</script>";;
			
	}
}





?>







</html>